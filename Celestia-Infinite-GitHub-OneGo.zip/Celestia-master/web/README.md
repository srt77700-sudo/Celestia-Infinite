# Celestia Infinite — Web build

This tree keeps the original Celestia C++ engine and adds the Celestia Infinite control layer.

## Modes
- **Explore**: original Celestia universe/renderer/navigation.
- **Simulate**: Infinite Simulation Lab controller with deterministic N-body particles.
- **Eclipses**: Infinite eclipse mode and geometry classifier.

## Infinite controls
- `I`: Explore
- `S`: Simulation Lab
- `E`: Eclipse mode
- `G`: toggle **Keep Solar Glare Constant**
- Browser buttons expose the same controls.

The default solar-glare behavior is FOV-only pinch zoom; disabling the option restores physical orbit-distance zoom.
