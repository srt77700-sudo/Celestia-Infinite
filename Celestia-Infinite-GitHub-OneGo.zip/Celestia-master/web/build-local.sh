#!/usr/bin/env bash
set -euo pipefail
: "${EMSDK:?Set EMSDK to an Emscripten SDK installation}"
source "$EMSDK/emsdk_env.sh" >/dev/null
emcmake cmake -S . -B build-web -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX="$PWD/install-web" \
  -DENABLE_WEB=ON -DENABLE_SDL=ON -DENABLE_GLES=ON \
  -DENABLE_CELX=OFF -DENABLE_NLS=OFF -DENABLE_SPICE=OFF \
  -DENABLE_FFMPEG=OFF -DENABLE_LIBAVIF=OFF -DENABLE_MINIAUDIO=OFF \
  -DENABLE_TOOLS=OFF -DENABLE_TESTS=OFF \
  -DCMAKE_CXX_FLAGS="-sUSE_SDL=2 -sUSE_FREETYPE=1 -sUSE_LIBPNG=1 -sUSE_LIBJPEG=1 -sUSE_ZLIB=1 -sMIN_WEBGL_VERSION=2 -sMAX_WEBGL_VERSION=2 -sALLOW_MEMORY_GROWTH=1 -sEXPORTED_FUNCTIONS=['_main','_ci_get_mode','_ci_set_mode','_ci_toggle_solar_glare','_ci_sim_clear','_ci_sim_add_body','_ci_sim_body_count','_ci_eclipse_type','_ci_galaxy_merger'] -sEXPORTED_RUNTIME_METHODS=['ccall','cwrap']" \
  -DCMAKE_EXE_LINKER_FLAGS="-sUSE_SDL=2 -sUSE_FREETYPE=1 -sUSE_LIBPNG=1 -sUSE_LIBJPEG=1 -sUSE_ZLIB=1 -sMIN_WEBGL_VERSION=2 -sMAX_WEBGL_VERSION=2 -sALLOW_MEMORY_GROWTH=1 -sEXPORTED_FUNCTIONS=['_main','_ci_get_mode','_ci_set_mode','_ci_toggle_solar_glare','_ci_sim_clear','_ci_sim_add_body','_ci_sim_body_count','_ci_eclipse_type','_ci_galaxy_merger'] -sEXPORTED_RUNTIME_METHODS=['ccall','cwrap']"
cmake --build build-web --parallel
cmake --install build-web
