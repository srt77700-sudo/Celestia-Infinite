(function () {
  const root = document.createElement('div');
  root.id = 'ci-ui';
  root.innerHTML = `
    <div class="ci-brand">CELESTIA <b>INFINITE</b></div>
    <div class="ci-tabs">
      <button data-mode="0">EXPLORE</button>
      <button data-mode="1">SIMULATE</button>
      <button data-mode="2">ECLIPSES</button>
    </div>
    <div class="ci-actions">
      <button id="ci-go">GO TO</button>
      <button id="ci-add">ADD TO SIMULATION</button>
      <button id="ci-galaxy">GALAXY MERGER</button>
    </div>
    <label class="ci-toggle"><input id="ci-glare" type="checkbox" checked> Keep Solar Glare Constant</label>
    <div id="ci-hint">Original Celestia engine • Infinite mode enabled</div>`;
  document.body.appendChild(root);

  const call = (name, ...args) => {
    if (window.Module && typeof Module.ccall === 'function') return Module.ccall(name, null, args.map(a => typeof a === 'number' ? 'number' : 'string'), args);
    if (window.Module && typeof Module[name] === 'function') return Module[name](...args);
  };
  root.querySelectorAll('[data-mode]').forEach(btn => btn.addEventListener('click', () => call('ci_set_mode', Number(btn.dataset.mode))));
  root.querySelector('#ci-glare').addEventListener('change', e => call('ci_toggle_solar_glare', e.target.checked ? 1 : 0));
  root.querySelector('#ci-add').addEventListener('click', () => {
    call('ci_set_mode', 1);
    call('ci_sim_add_body', 1, 1, 0, 0, 0, 0, 0.35, 0);
  });
  root.querySelector('#ci-galaxy').addEventListener('click', () => {
    call('ci_set_mode', 1);
    call('ci_galaxy_merger', 0xCE1E571A, 128);
  });
})();
