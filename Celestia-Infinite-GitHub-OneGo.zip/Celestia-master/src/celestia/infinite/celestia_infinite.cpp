#include "celestia_infinite.h"

#include <algorithm>
#include <cmath>
#include <limits>

namespace celestia::infinite {

Controller::Controller() = default;

void Controller::tick(double dt)
{
    if (dt <= 0.0 || !std::isfinite(dt))
        return;
    if (m_mode == Mode::Simulate)
        integrateNBody(std::min(dt, 0.25));
}

void Controller::setMode(Mode mode)
{
    m_mode = mode;
}

void Controller::clearSimulation()
{
    m_bodies.clear();
}

int Controller::addBody(const Body& body)
{
    m_bodies.push_back(body);
    return static_cast<int>(m_bodies.size() - 1);
}

const Body* Controller::body(std::size_t index) const
{
    return index < m_bodies.size() ? &m_bodies[index] : nullptr;
}

void Controller::createGalaxyMerger(std::uint64_t seed, int particlesPerGalaxy)
{
    m_bodies.clear();
    particlesPerGalaxy = std::clamp(particlesPerGalaxy, 16, 1024);
    m_universeSeed = seed;

    auto unit = [](std::uint64_t z) {
        z ^= z >> 30; z *= 0xbf58476d1ce4e5b9ULL;
        z ^= z >> 27; z *= 0x94d049bb133111ebULL;
        z ^= z >> 31;
        return (static_cast<double>(z & 0xffffffffULL) / 4294967295.0) * 2.0 - 1.0;
    };

    // Two compact rotating stellar systems. They are intentionally represented
    // by particles so the simulation remains real N-body dynamics rather than
    // an animation. Increase the count for heavier experiments.
    for (int galaxy = 0; galaxy < 2; ++galaxy)
    {
        const double cx = galaxy == 0 ? -18.0 : 18.0;
        const double vy = galaxy == 0 ? 0.8 : -0.8;
        for (int i = 0; i < particlesPerGalaxy; ++i)
        {
            const auto seedValue = proceduralStarSeed(static_cast<std::uint64_t>(i + galaxy * 100000)) ^ seed;
            const double r = 2.0 + 12.0 * (0.5 + 0.5 * unit(seedValue));
            const double a = 6.283185307179586 * (0.5 + 0.5 * unit(seedValue + 1));
            const double z = 0.8 * unit(seedValue + 2);
            Body b;
            b.mass = 1.0;
            b.radius = 0.08;
            b.x = cx + r * std::cos(a);
            b.y = r * std::sin(a);
            b.z = z;
            b.vx = -std::sin(a) * 0.9;
            b.vy = std::cos(a) * 0.9 + vy;
            b.vz = 0.02 * unit(seedValue + 3);
            m_bodies.push_back(b);
        }
    }
    m_mode = Mode::Simulate;
}

EclipseState Controller::classifyEclipse(double separation,
                                         double sourceRadius,
                                         double occultorRadius)
{
    EclipseState e;
    e.separation = std::max(0.0, separation);
    e.sourceRadius = std::max(0.0, sourceRadius);
    e.occultorRadius = std::max(0.0, occultorRadius);

    const double a = e.sourceRadius;
    const double b = e.occultorRadius;
    const double d = e.separation;

    if (d >= a + b)
        e.type = EclipseType::None;
    else if (b >= a && d + a <= b)
        e.type = EclipseType::Total;
    else if (a > b && d + b <= a)
        e.type = EclipseType::Annular;
    else
        e.type = EclipseType::Partial;

    return e;
}

std::uint64_t Controller::proceduralStarSeed(std::uint64_t index) const
{
    // SplitMix64: fast, deterministic and independent of platform RNG state.
    std::uint64_t z = m_universeSeed + index + 0x9e3779b97f4a7c15ULL;
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    return z ^ (z >> 31);
}

void Controller::integrateNBody(double dt)
{
    if (m_bodies.size() < 2)
        return;

    constexpr double G = 1.0;
    constexpr double softening2 = 1e-8;
    std::vector<double> ax(m_bodies.size()), ay(m_bodies.size()), az(m_bodies.size());

    for (std::size_t i = 0; i < m_bodies.size(); ++i)
    {
        if (!m_bodies[i].active) continue;
        for (std::size_t j = i + 1; j < m_bodies.size(); ++j)
        {
            if (!m_bodies[j].active) continue;
            const double dx = m_bodies[j].x - m_bodies[i].x;
            const double dy = m_bodies[j].y - m_bodies[i].y;
            const double dz = m_bodies[j].z - m_bodies[i].z;
            const double r2 = dx*dx + dy*dy + dz*dz + softening2;
            const double invR = 1.0 / std::sqrt(r2);
            const double invR3 = invR * invR * invR;
            const double f = G * invR3;
            ax[i] += dx * f * m_bodies[j].mass;
            ay[i] += dy * f * m_bodies[j].mass;
            az[i] += dz * f * m_bodies[j].mass;
            ax[j] -= dx * f * m_bodies[i].mass;
            ay[j] -= dy * f * m_bodies[i].mass;
            az[j] -= dz * f * m_bodies[i].mass;
        }
    }

    // Kick-drift-Kick (velocity Verlet) in the compact simulation lab.
    for (std::size_t i = 0; i < m_bodies.size(); ++i)
    {
        if (!m_bodies[i].active) continue;
        m_bodies[i].vx += 0.5 * ax[i] * dt;
        m_bodies[i].vy += 0.5 * ay[i] * dt;
        m_bodies[i].vz += 0.5 * az[i] * dt;
        m_bodies[i].x += m_bodies[i].vx * dt;
        m_bodies[i].y += m_bodies[i].vy * dt;
        m_bodies[i].z += m_bodies[i].vz * dt;
    }

    std::fill(ax.begin(), ax.end(), 0.0);
    std::fill(ay.begin(), ay.end(), 0.0);
    std::fill(az.begin(), az.end(), 0.0);

    for (std::size_t i = 0; i < m_bodies.size(); ++i)
    {
        if (!m_bodies[i].active) continue;
        for (std::size_t j = i + 1; j < m_bodies.size(); ++j)
        {
            if (!m_bodies[j].active) continue;
            const double dx = m_bodies[j].x - m_bodies[i].x;
            const double dy = m_bodies[j].y - m_bodies[i].y;
            const double dz = m_bodies[j].z - m_bodies[i].z;
            const double r2 = dx*dx + dy*dy + dz*dz + softening2;
            const double invR = 1.0 / std::sqrt(r2);
            const double f = G * invR * invR * invR;
            ax[i] += dx * f * m_bodies[j].mass;
            ay[i] += dy * f * m_bodies[j].mass;
            az[i] += dz * f * m_bodies[j].mass;
            ax[j] -= dx * f * m_bodies[i].mass;
            ay[j] -= dy * f * m_bodies[i].mass;
            az[j] -= dz * f * m_bodies[i].mass;
        }
    }

    for (std::size_t i = 0; i < m_bodies.size(); ++i)
    {
        if (!m_bodies[i].active) continue;
        m_bodies[i].vx += 0.5 * ax[i] * dt;
        m_bodies[i].vy += 0.5 * ay[i] * dt;
        m_bodies[i].vz += 0.5 * az[i] * dt;
    }
}

} // namespace celestia::infinite
