#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace celestia::infinite {

enum class Mode : int { Explore = 0, Simulate = 1, Eclipses = 2 };

enum class EclipseType : int { None = 0, Partial = 1, Total = 2, Annular = 3 };

struct Body {
    double mass = 1.0;
    double radius = 1.0;
    double x = 0.0, y = 0.0, z = 0.0;
    double vx = 0.0, vy = 0.0, vz = 0.0;
    bool active = true;
};

struct EclipseState {
    EclipseType type{EclipseType::None};
    double separation = 0.0;
    double sourceRadius = 1.0;
    double occultorRadius = 1.0;
};

class Controller {
public:
    Controller();

    void tick(double dt);
    void setMode(Mode mode);
    Mode mode() const { return m_mode; }

    void setSolarGlareLocked(bool enabled) { m_solarGlareLocked = enabled; }
    bool solarGlareLocked() const { return m_solarGlareLocked; }

    void clearSimulation();
    int addBody(const Body& body);
    void createGalaxyMerger(std::uint64_t seed, int particlesPerGalaxy);
    void stepSimulation(double dt);
    std::size_t bodyCount() const { return m_bodies.size(); }
    const Body* body(std::size_t index) const;

    static EclipseState classifyEclipse(double separation,
                                        double sourceRadius,
                                        double occultorRadius);

    // Deterministic procedural seed used by the Infinite universe layer.
    void setUniverseSeed(std::uint64_t seed) { m_universeSeed = seed; }
    std::uint64_t universeSeed() const { return m_universeSeed; }
    std::uint64_t proceduralStarSeed(std::uint64_t index) const;

private:
    void integrateNBody(double dt);

    Mode m_mode{Mode::Explore};
    bool m_solarGlareLocked{true};
    std::uint64_t m_universeSeed{0xCE1E571AULL};
    std::vector<Body> m_bodies;
};

} // namespace celestia::infinite
