# Celestia — original engine, browser build

This repository keeps the upstream Celestia C++ engine and adds a WebAssembly/WebGL build path.

## GitHub phone workflow

1. Fork the repository.
2. Open **Actions**.
3. Run **Build Original Celestia WebAssembly** with **Run workflow**.
4. When it finishes, open the workflow run and download **celestia-original-web**.
5. Extract it and serve the folder from an HTTP(S) server; open `index.html` in a modern browser.
6. If an APK is wanted, first let the web workflow succeed, then run **Build Celestia Android APK from WebAssembly**. Download `celestia-web-android-debug` from that workflow.

The APK is a WebView wrapper around the same generated WebAssembly build; it does not replace Celestia with a JavaScript renderer.

## Architecture

- Original Celestia C++ engine and renderer.
- Existing SDL frontend, including Celestia's Emscripten main loop.
- WebGL 2 / OpenGL ES 3.
- CelestiaContent fetched during the GitHub build.
- Content is preloaded into Emscripten's virtual filesystem at `/celestia-data`.
- Optional desktop-only features are disabled for the initial browser bootstrap so the core engine can be brought up first.

After the original browser build is verified, Celestia Infinite features can be added directly to this same engine rather than building a second renderer.
